package com.jimweller.cpuscheduler;

//import CPUSchedulerFrame;
//import CPUScheduler;

/**
 * Run this with java to get a CPUSchedulerFrame from the local workstation
 */
public class MainApp   {

    
    public static void main(String args[]){

    CPUScheduler cpu = new CPUScheduler();
    //cpu.Simulate();
    //cpu.printCSV();
    CPUSchedulerFrame fr = new CPUSchedulerFrame();


    }



}
