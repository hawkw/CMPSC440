package com.jimweller.cpuscheduler;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.*;
import java.applet.Applet;

/** very simple container for a CPUSchedulerFrameForApplet class
*/
public class JunkApplet extends JApplet {

    public void init(){
       	CPUSchedulerFrameForApplet cf = new CPUSchedulerFrameForApplet();
    }
    

}
 
